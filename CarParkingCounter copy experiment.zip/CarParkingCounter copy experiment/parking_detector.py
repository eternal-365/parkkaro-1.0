import cv2
import pickle
import cvzone
import numpy as np
import threading
import time
import os
from datetime import datetime


class ParkingDetector:
    def __init__(self):
        self.posList = []
        self.width, self.height = 107, 48
        self.parking_data = {
            'free_spaces': 0,
            'total_spaces': 0,
            'free_lots': [],
            'occupied_lots': [],
            'last_update': 'Never'
        }
        self.load_parking_spaces()
        self.running = False
        self.detection_thread = None
        self.img_path = 'assets/carParkImg.png'

    def load_parking_spaces(self):
        """Load parking space positions"""
        try:
            with open('assets/positions.pkl', 'rb') as f:
                self.posList = pickle.load(f)
            self.parking_data['total_spaces'] = len(self.posList)
            print(f"✅ Loaded {len(self.posList)} parking spaces")
        except Exception as e:
            print(f"❌ Error loading parking spaces: {e}")
            self.posList = []

    def check_parking_space(self, imgPro):
        """Check parking space occupancy"""
        spaceCounter = 0
        free_lots = []
        occupied_lots = []

        for i, pos in enumerate(self.posList):
            x, y = pos
            lot_number = i + 1

            imgCrop = imgPro[y:y + self.height, x:x + self.width]
            count = cv2.countNonZero(imgCrop)

            if count < 900:  # Free space
                spaceCounter += 1
                free_lots.append(lot_number)
            else:  # Occupied space
                occupied_lots.append(lot_number)

        return spaceCounter, free_lots, occupied_lots

    def update_parking_status(self):
        """Continuously update parking status from static image"""
        frame_count = 0

        while self.running:
            try:
                # Load the static image each time
                img = cv2.imread(self.img_path)

                if img is None:
                    print(f"❌ Failed to load image from {self.img_path}")
                    time.sleep(5)
                    continue

                # Image processing
                imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                imgBlur = cv2.GaussianBlur(imgGray, (3, 3), 1)
                imgThreshold = cv2.adaptiveThreshold(imgBlur, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                                     cv2.THRESH_BINARY_INV, 25, 16)
                imgMedian = cv2.medianBlur(imgThreshold, 5)
                kernel = np.ones((3, 3), np.uint8)
                imgDilate = cv2.dilate(imgMedian, kernel, iterations=1)

                # Check parking spaces
                free_spaces, free_lots, occupied_lots = self.check_parking_space(imgDilate)

                # Update parking data
                self.parking_data.update({
                    'free_spaces': free_spaces,
                    'total_spaces': len(self.posList),
                    'free_lots': free_lots,
                    'occupied_lots': occupied_lots,
                    'last_update': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                })

                # Only print every 10 updates to reduce terminal spam
                if frame_count % 10 == 0:
                    print(f"🅿️  Detection: {free_spaces}/{len(self.posList)} free | Free lots: {free_lots}")

                frame_count += 1

            except Exception as e:
                print(f"❌ Detection error: {e}")

            time.sleep(3)  # Check every 3 seconds

    def start_detection(self):
        """Start the parking detection in background"""
        if not self.posList:
            print("⚠️  No parking spaces defined")
            return False

        if not os.path.exists(self.img_path):
            print(f"❌ Parking image not found at {self.img_path}")
            return False

        self.running = True
        self.detection_thread = threading.Thread(target=self.update_parking_status, daemon=True)
        self.detection_thread.start()
        print("✅ Parking detection started")
        return True

    def stop_detection(self):
        """Stop the parking detection"""
        self.running = False
        if self.detection_thread:
            self.detection_thread.join()

    def get_parking_data(self):
        """Get current parking data"""
        return self.parking_data.copy()

    def assign_parking_lot(self, lot_number):
        """Assign a parking lot (mark as occupied)"""
        try:
            if lot_number in self.parking_data['free_lots']:
                self.parking_data['free_lots'].remove(lot_number)
                self.parking_data['occupied_lots'].append(lot_number)
                self.parking_data['free_spaces'] = len(self.parking_data['free_lots'])
                print(f"✅ Detector: Assigned lot {lot_number}")
                return True
            else:
                print(f"⚠️ Detector: Lot {lot_number} not available in free lots")
                return False
        except Exception as e:
            print(f"❌ Detector: Error assigning lot {lot_number}: {e}")
            return False

    def free_parking_lot(self, lot_number):
        """Free a parking lot (mark as available)"""
        try:
            if lot_number in self.parking_data['occupied_lots']:
                self.parking_data['occupied_lots'].remove(lot_number)
                self.parking_data['free_lots'].append(lot_number)
                self.parking_data['free_spaces'] = len(self.parking_data['free_lots'])
                print(f"✅ Detector: Freed lot {lot_number}")
                return True
            else:
                print(f"⚠️ Detector: Lot {lot_number} not found in occupied lots")
                return False
        except Exception as e:
            print(f"❌ Detector: Error freeing lot {lot_number}: {e}")
            return False

    def free_parking_lot(self, lot_number):
        """Free a parking lot (mark as available)"""
        if lot_number in self.parking_data['occupied_lots']:
            self.parking_data['occupied_lots'].remove(lot_number)
            self.parking_data['free_lots'].append(lot_number)
            self.parking_data['free_spaces'] += 1
            return True
        return False


# Global instance
parking_detector = ParkingDetector()