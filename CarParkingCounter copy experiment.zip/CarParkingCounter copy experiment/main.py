import cv2
import pickle
import cvzone
import numpy as np
import os

# Video feed (use 0 for camera, or video file)
cap = cv2.VideoCapture('assets/carParkImg.png')
# Load parking spaces with lot numbers
with open('assets/positions.pkl', 'rb') as f:
    posList = pickle.load(f)

width, height = 107, 48


def checkParkingSpace(imgPro):
    spaceCounter = 0
    free_lots = []
    occupied_lots = []

    for i, pos in enumerate(posList):
        x, y = pos

        imgCrop = imgPro[y:y + height, x:x + width]
        count = cv2.countNonZero(imgCrop)
        lot_number = i + 1

        if count < 900:
            color = (0, 255, 0)  # Green - Free
            thickness = 5
            spaceCounter += 1
            free_lots.append(lot_number)
            status = "FREE"
        else:
            color = (0, 0, 255)  # Red - Occupied
            thickness = 2
            occupied_lots.append(lot_number)
            status = "BUSY"

        # Draw rectangle
        cv2.rectangle(img, pos, (pos[0] + width, pos[1] + height), color, thickness)

        # Display lot number and status
        cvzone.putTextRect(img, f'Lot {lot_number}', (x, y - 5), scale=1, thickness=2, offset=3, colorR=color)
        cvzone.putTextRect(img, status, (x, y + height - 3), scale=0.8, thickness=1, offset=0, colorR=color)

    # Display overall count
    cvzone.putTextRect(img, f'Free: {spaceCounter}/{len(posList)}', (100, 50), scale=3, thickness=5, offset=20,
                       colorR=(0, 200, 0))

    # Display in terminal
    print("\n" + "=" * 50)
    print("PARKING LOT STATUS")
    print("=" * 50)
    print(f"FREE LOTS ({spaceCounter}/{len(posList)}): {free_lots}")
    print(f"BUSY LOTS ({len(occupied_lots)}/{len(posList)}): {occupied_lots}")
    print("-" * 50)

    return spaceCounter, free_lots, occupied_lots


# Counter to reduce terminal spam
frame_count = 0

while True:
    # Loop video
    if cap.get(cv2.CAP_PROP_POS_FRAMES) == cap.get(cv2.CAP_PROP_FRAME_COUNT):
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)

    success, img = cap.read()
    if not success:
        print("Failed to read frame")
        break

    # Image processing
    imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    imgBlur = cv2.GaussianBlur(imgGray, (3, 3), 1)
    imgThreshold = cv2.adaptiveThreshold(imgBlur, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                         cv2.THRESH_BINARY_INV, 25, 16)
    imgMedian = cv2.medianBlur(imgThreshold, 5)
    kernel = np.ones((3, 3), np.uint8)
    imgDilate = cv2.dilate(imgMedian, kernel, iterations=1)

    # Only print to terminal every 30 frames to reduce spam
    if frame_count % 30 == 0:
        free_count, free_lots, occupied_lots = checkParkingSpace(imgDilate)
    else:
        free_count, _, _ = checkParkingSpace(imgDilate)

    frame_count += 1

    cv2.imshow("Parking System", img)

    # Press 'q' to quit, 'r' to refresh terminal display
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break
    elif key == ord('r'):
        # Force refresh display
        free_count, free_lots, occupied_lots = checkParkingSpace(imgDilate)

# Final status
print("\n" + "=" * 50)
print("FINAL PARKING STATUS")
print("=" * 50)
print(f"Total parking lots: {len(posList)}")
print("Lot positions:")
for i, pos in enumerate(posList):
    print(f"Lot {i + 1}: {pos}")

cap.release()
cv2.destroyAllWindows()