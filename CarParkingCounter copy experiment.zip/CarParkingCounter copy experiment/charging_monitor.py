import sqlite3
import threading
import time
from datetime import datetime


class ChargingMonitor:
    def __init__(self):
        self.charging_sessions = {}
        self.monitoring = False
        self.monitor_thread = None
        self.post_100_times = {}  # session_id -> timestamp when reached 100%

    def start_charging_session(self, user_id, parking_session_id, start_charge_level=0):
        """Start a new charging session"""
        try:
            conn = sqlite3.connect('parking_system.db')
            c = conn.cursor()

            c.execute('''
                INSERT INTO charging_sessions 
                (user_id, parking_session_id, start_charge_level, current_charge_level, status)
                VALUES (?, ?, ?, ?, 'active')
            ''', (user_id, parking_session_id, start_charge_level, start_charge_level))

            session_id = c.lastrowid
            conn.commit()
            conn.close()

            self.charging_sessions[session_id] = {
                'user_id': user_id,
                'current_charge': start_charge_level,
                'status': 'active',
                'last_updated': datetime.now()
            }

            print(f"🔌 Charging session started: Session {session_id}, User {user_id}, Start: {start_charge_level}%")
            return session_id

        except Exception as e:
            print(f"❌ Error starting charging session: {e}")
            return None

    def update_charge_level(self, session_id, charge_level):
        """Update charge level for a session - record completion time at 100%"""
        try:
            print(f"🔋 Attempting to update charge level - Session: {session_id}, Level: {charge_level}%")

            # Validate charge level
            if not (0 <= charge_level <= 100):
                print(f"❌ Invalid charge level: {charge_level}%")
                return False

            conn = sqlite3.connect('parking_system.db')
            c = conn.cursor()

            # First, check if session exists
            c.execute('SELECT id, user_id, status, current_charge_level FROM charging_sessions WHERE id = ?',
                      (session_id,))
            session = c.fetchone()

            if not session:
                print(f"❌ Charging session {session_id} not found in database")
                conn.close()
                return False

            session_id_db, user_id, status, current_charge = session

            print(f"✅ Session found: ID={session_id}, User={user_id}, Status={status}, Current: {current_charge}%")

            # Check if this update is reaching 100% for the first time
            is_first_time_100 = (current_charge < 100 and charge_level >= 100)

            # Update current charge level
            if is_first_time_100:
                # Record completion time when first reaching 100%
                completion_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                c.execute('''
                    UPDATE charging_sessions 
                    SET current_charge_level = ?, 
                        total_energy = total_energy + ABS(? - current_charge_level) * charging_rate / 100,
                        completion_time = ?
                    WHERE id = ?
                ''', (charge_level, charge_level, completion_time, session_id))
                print(f"⏰ Recorded completion time: {completion_time}")
            else:
                c.execute('''
                    UPDATE charging_sessions 
                    SET current_charge_level = ?, 
                        total_energy = total_energy + ABS(? - current_charge_level) * charging_rate / 100
                    WHERE id = ?
                ''', (charge_level, charge_level, session_id))

            rows_affected = c.rowcount
            print(f"📊 Database update - Rows affected: {rows_affected}")

            # Update in-memory session
            if session_id in self.charging_sessions:
                self.charging_sessions[session_id]['current_charge'] = charge_level
                self.charging_sessions[session_id]['last_updated'] = datetime.now()
                if is_first_time_100:
                    self.charging_sessions[session_id]['completion_time'] = completion_time
            else:
                self.charging_sessions[session_id] = {
                    'user_id': user_id,
                    'current_charge': charge_level,
                    'status': 'active',
                    'last_updated': datetime.now()
                }
                if is_first_time_100:
                    self.charging_sessions[session_id]['completion_time'] = completion_time

            conn.commit()
            conn.close()

            print(f"✅ Charge updated successfully: Session {session_id}, Level: {charge_level}%")

            if charge_level >= 100:
                if is_first_time_100:
                    print(f"🎯 FIRST TIME 100% - Session {session_id} is fully charged at {completion_time}")
                    return 'first_time_complete'
                else:
                    print(f"🎯 Already at 100% - Session {session_id} remains fully charged")
                    return 'complete'

            return True

        except Exception as e:
            print(f"❌ Error updating charge level: {str(e)}")
            import traceback
            print("🔍 Full traceback:")
            traceback.print_exc()
            return False



    def complete_charging_session(self, session_id):
        """Complete a charging session"""
        try:
            if session_id not in self.charging_sessions:
                return False

            conn = sqlite3.connect('parking_system.db')
            c = conn.cursor()

            # Get session details
            c.execute('SELECT current_charge_level FROM charging_sessions WHERE id = ?', (session_id,))
            current_charge = c.fetchone()[0]

            # Update session as completed
            c.execute('''
                UPDATE charging_sessions 
                SET end_time = ?, end_charge_level = ?, status = 'completed'
                WHERE id = ?
            ''', (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), current_charge, session_id))

            conn.commit()
            conn.close()

            # Remove from active sessions
            user_id = self.charging_sessions[session_id]['user_id']
            del self.charging_sessions[session_id]

            print(f"✅ Charging completed: Session {session_id}, Final: {current_charge}%")

            # Send notification (you can integrate with your notification system)
            self.send_charging_complete_notification(user_id, session_id)

            return True

        except Exception as e:
            print(f"❌ Error completing charging session: {e}")
            return False

    def send_charging_complete_notification(self, user_id, session_id):
        """Send charging complete notification"""
        print(f"📢 Charging complete notification sent to user {user_id} for session {session_id}")
        # Here you can integrate with:
        # - Email notifications
        # - SMS notifications
        # - Push notifications
        # - WebSocket updates

    def get_user_charging_status(self, user_id):
        """Get charging status for a user - include completion time"""
        try:
            conn = sqlite3.connect('parking_system.db')
            c = conn.cursor()

            # Get the most recent session (active OR completed)
            c.execute('''
                SELECT cs.id, cs.current_charge_level, cs.status, cs.start_time, 
                       cs.completion_time, u.username
                FROM charging_sessions cs
                JOIN users u ON cs.user_id = u.id
                WHERE cs.user_id = ?
                ORDER BY cs.start_time DESC
                LIMIT 1
            ''', (user_id,))

            session = c.fetchone()
            conn.close()

            if session:
                session_id, current_charge, status, start_time, completion_time, username = session
                return {
                    'session_id': session_id,
                    'current_charge': current_charge,
                    'status': status,
                    'start_time': start_time,
                    'completion_time': completion_time,  # Add completion time
                    'username': username,
                    'is_complete': current_charge >= 100
                }
            return None

        except Exception as e:
            print(f"❌ Error getting charging status: {e}")
            return None

    def get_all_active_charging_sessions(self):
        """Get all active charging sessions"""
        try:
            conn = sqlite3.connect('parking_system.db')
            c = conn.cursor()

            c.execute('''
                SELECT cs.id, u.username, cs.current_charge_level, cs.start_time
                FROM charging_sessions cs
                JOIN users u ON cs.user_id = u.id
                WHERE cs.status = 'active'
                ORDER BY cs.start_time DESC
            ''')

            sessions = c.fetchall()
            conn.close()

            return [{
                'session_id': session[0],
                'username': session[1],
                'current_charge': session[2],
                'start_time': session[3]
            } for session in sessions]

        except Exception as e:
            print(f"❌ Error getting active sessions: {e}")
            return []

    def stop_user_charging_session(self, user_id):
        """Stop all active charging sessions for a user"""
        try:
            conn = sqlite3.connect('parking_system.db')
            c = conn.cursor()

            # Get active charging sessions for user
            c.execute('SELECT id, current_charge_level FROM charging_sessions WHERE user_id = ? AND status = "active"',
                      (user_id,))
            active_sessions = c.fetchall()

            # Complete each active session
            for session_id, current_charge in active_sessions:
                c.execute('''
                    UPDATE charging_sessions 
                    SET end_time = ?, end_charge_level = ?, status = 'completed'
                    WHERE id = ?
                ''', (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), current_charge, session_id))

                # Remove from active sessions
                if session_id in self.charging_sessions:
                    del self.charging_sessions[session_id]

            conn.commit()
            conn.close()

            print(f"✅ Stopped {len(active_sessions)} charging sessions for user {user_id}")
            return len(active_sessions)

        except Exception as e:
            print(f"❌ Error stopping user charging sessions: {e}")
            return 0


# Global instance
charging_monitor = ChargingMonitor()