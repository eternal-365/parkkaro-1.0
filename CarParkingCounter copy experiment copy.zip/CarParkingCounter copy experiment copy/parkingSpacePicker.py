import cv2
import pickle
import os
import numpy as np

# Check if assets directory exists, if not create it
if not os.path.exists('assets'):
    os.makedirs('assets')
    print("Created 'assets' directory")

# Parking space dimensions
width, height = 107, 48

# Load or create positions list
positions_file = 'assets/positions.pkl'
try:
    if os.path.exists(positions_file):
        with open(positions_file, 'rb') as f:
            posList = pickle.load(f)
        print(f"Loaded {len(posList)} parking spaces")
    else:
        posList = []
        print("Starting with empty parking spaces list")
except Exception as e:
    print(f"Error loading positions: {e}")
    posList = []


def mouseClick(events, x, y, flags, params):
    if events == cv2.EVENT_LBUTTONDOWN:
        posList.append((x, y))
        print(f"Added Lot {len(posList)} at position ({x}, {y})")

    if events == cv2.EVENT_RBUTTONDOWN:
        for i, pos in enumerate(posList):
            x1, y1 = pos
            if x1 < x < x1 + width and y1 < y < y1 + height:
                removed_pos = posList.pop(i)
                print(f"Removed Lot {i + 1} at position {removed_pos}")
                break

    # Save positions
    try:
        with open(positions_file, 'wb') as f:
            pickle.dump(posList, f)
    except Exception as e:
        print(f"Error saving positions: {e}")


# Load the image with error checking
image_path = 'assets/carParkImg.png'

if not os.path.exists(image_path):
    print(f"ERROR: Image file not found at {image_path}")
    img = np.ones((500, 800, 3), dtype=np.uint8) * 255
    print("Using blank image as fallback.")
else:
    img = cv2.imread(image_path)
    if img is None:
        print("ERROR: Could not read the image file")
        img = np.ones((500, 800, 3), dtype=np.uint8) * 255
    else:
        print(f"Image loaded successfully: {img.shape}")

# Create window and set mouse callback
cv2.namedWindow("Parking Space Picker")
cv2.setMouseCallback("Parking Space Picker", mouseClick)

print("\nINSTRUCTIONS:")
print("- LEFT CLICK: Add parking space")
print("- RIGHT CLICK: Remove parking space")
print("- Press 'q': Quit and save")
print("- Press 'c': Clear all spaces")

while True:
    img_display = img.copy()

    # Draw all parking spaces with lot numbers
    for i, pos in enumerate(posList):
        x, y = pos
        cv2.rectangle(img_display, pos, (x + width, y + height), (255, 0, 255), 2)
        # Add lot number
        cv2.putText(img_display, f'Lot {i + 1}', (x + 5, y + 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 255), 2)

    # Display counter
    cv2.putText(img_display, f'Total Lots: {len(posList)}', (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
    cv2.putText(img_display, 'Left Click: Add | Right Click: Remove | Q: Quit', (10, 70),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)

    cv2.imshow("Parking Space Picker", img_display)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break
    elif key == ord('c'):
        posList.clear()
        print("Cleared all parking spaces")

# Final save
try:
    with open(positions_file, 'wb') as f:
        pickle.dump(posList, f)
    print(f"\nSaved {len(posList)} parking spaces to {positions_file}")
    print("Lot assignments:")
    for i, pos in enumerate(posList):
        print(f"Lot {i + 1}: Position {pos}")
except Exception as e:
    print(f"Error during final save: {e}")

cv2.destroyAllWindows()
print("Parking space picker closed")




